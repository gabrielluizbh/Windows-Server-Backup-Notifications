﻿# Script de envio de e-mail

$emailSmtpServer = "smtp.gmail.com" # Servidor SMTP.
$emailSmtpServerPort = "587" # Porta do Servidor SMTP.
$emailSmtpUser = "gabrielluizbhz" # Usuário do e-mail.
$emailSmtpPass = "jkl4050602021" # Senha do e-mail.
 
$emailMessage = New-Object System.Net.Mail.MailMessage
$emailMessage.From = "Servidor de Backup SRV01 <gabrielluizbhz@gmail.com>" # E-mail remetente.
$emailMessage.To.Add( "gabrielluiz@msn.com" ) # E-mail destinatário.
$emailMessage.Subject = "Confirmação do Backup - Feito sem sucesso" # Assunto do e-mail.
$emailMessage.IsBodyHtml = $true # Habilita o e-mail HTML.
$emailMessage.Body = "Backup feito sem sucesso,favor verificar." # Mensagem do e-mail.
 
$SMTPClient = New-Object System.Net.Mail.SmtpClient( $emailSmtpServer , $emailSmtpServerPort )
$SMTPClient.EnableSsl = $true # Habilita a criptografía SSL no email.
$SMTPClient.Credentials = New-Object System.Net.NetworkCredential( $emailSmtpUser , $emailSmtpPass );
$SMTPClient.Send( $emailMessage )